"""Step 12: connect frontend triggers to backend APIs through functional smoke tests."""

from contextlib import ExitStack
from pathlib import Path

from infrastructure.utils.cli import create_parser, resolve_directories
from infrastructure.stages.frontend.triggers.context import load_e2e_context
from infrastructure.stages.frontend.triggers.implementation import run_trigger_tdd, verify_frontend
from infrastructure.stages.frontend.triggers.acceptance import (
    run_independent_acceptance, original_requirements, prepare_acceptance_suite,
    review_acceptance_suite, acceptance_path)
from infrastructure.shared.models.text import TextModel
from infrastructure.utils.presentation.console import DemoConsole
from infrastructure.utils.presentation.logging import console_log
from infrastructure.utils.files import save_json


def implement_frontend_triggers(input_dir: Path, arc_dir: Path, pause: bool = False,
        max_turns: int | None = None, max_tests: int = 2) -> dict:
    if (max_turns is not None and max_turns < 1) or max_tests < 1:
        raise ValueError("--max-turns and --max-tests must be positive")
    tree, schema, backend, ui, interactions, images, contexts = load_e2e_context(arc_dir, input_dir)
    report = {"status": "PREPARING", "requirements": {rid: {"status": "NO_DIRECT_TRIGGERS", "triggers": []}
        for rid in tree.requirements if tree.children[rid]}}
    save_json(arc_dir / "frontend_e2e.json", report)
    try:
        if not ui["pages"]:
            report.update({"status": "NO_UI", "summary": {"requirements": 0, "triggers": 0, "e2e_tests": 0, "ui_tests": 0, "failed": 0}})
            save_json(arc_dir / "frontend_e2e.json", report)
            return report
        model = TextModel()
        console = DemoConsole(pause)
        original_tree = original_requirements(input_dir)
        reviewed = set()
        test_owners = {acceptance_path(rid): rid for rid in original_tree.leaves}

        def acceptance_prepare(rid):
            return prepare_acceptance_suite(original_tree, arc_dir.parent.resolve(), schema,
                backend, ui, interactions, rid, model, console, max_turns)

        def acceptance_review(path, feedback):
            rid = test_owners.get(path)
            if rid is None:
                return False
            return review_acceptance_suite(original_tree, arc_dir.parent.resolve(), schema,
                backend, ui, interactions, rid, model, console, max_turns, feedback, reviewed)

        result = run_trigger_tdd(arc_dir, tree, schema, backend, ui, interactions, images,
            contexts, model, console, report, max_turns, max_tests,
            acceptance_prepare=acceptance_prepare, acceptance_review=acceptance_review)
        acceptance = run_independent_acceptance(input_dir, arc_dir, schema, backend, ui, interactions,
            model, DemoConsole(pause), max_turns, process_report=result)
        if any(entry.get("repair_checks") for entry in acceptance["requirements"].values()):
            result = verify_frontend(arc_dir, tree, backend, ui, DemoConsole(pause), result)
        result["verification"]["independent_acceptance"] = {"status": "GREEN" if acceptance["status"] == "GREEN" else "FAILED",
            "report": ".arc/independent_acceptance.json"}
        if acceptance["status"] != "GREEN":
            result["status"] = "COMPLETED_WITH_FAILURES"
        save_json(arc_dir / "frontend_e2e.json", result)
        print(f"Frontend functional smoke {result['status']}: {result['summary']}\nReport: {arc_dir / 'frontend_e2e.json'}", flush=True)
        return result
    except BaseException as error:
        report.update({"status": "FAILED", "error": str(error)})
        for requirement in report["requirements"].values():
            if requirement["status"] not in {"GREEN", "NO_TRIGGERS", "NO_DIRECT_TRIGGERS"}:
                requirement["status"] = "FAILED"
        save_json(arc_dir / "frontend_e2e.json", report)
        raise


def main() -> None:
    parser = create_parser("Step 12: Frontend/Backend Integration with Playwright Functional Smoke Tests")
    parser.add_argument("--max-turns", type=int, default=None, help="Optional limit (default: unlimited). Maximum edit rounds per requirement's test/implementation agent")
    parser.add_argument("--max-tests", type=int, default=2, help="Maximum functional smoke cases per requirement (default: 2)")
    args = parser.parse_args()
    with ExitStack() as stack:
        try:
            input_dir, output_dir = resolve_directories(args)
            stack.enter_context(console_log(output_dir, debug_model_io=args.debug_model_io))
            result = implement_frontend_triggers(input_dir, output_dir / ".arc", args.pause, args.max_turns, args.max_tests)
        except (OSError, ValueError, RuntimeError) as error:
            parser.exit(1, f"Execution failed: {error}\n")

    if result["status"] == "COMPLETED_WITH_FAILURES":
        parser.exit(1, "All implementation tasks were attempted; some acceptance checks failed. See the .arc report.\n")


if __name__ == "__main__":
    main()
